import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // group1bTX (1:55)
        width: double.infinity,
        height: 842*fem,
        child: Container(
          // dashboardxJ5 (1:54)
          padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
          width: double.infinity,
          height: double.infinity,
          decoration: BoxDecoration (
            border: Border.all(color: Color(0xff000000)),
            color: Color(0xffffffff),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                // autogrouprwmjfTP (Sff1g8THjVXDLHWW1ZrwMj)
                padding: EdgeInsets.fromLTRB(14*fem, 45*fem, 14*fem, 49*fem),
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      // hellonnu (1:37)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 9*fem),
                      width: double.infinity,
                      child: Text(
                        'Hello!',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 36*ffem,
                          fontWeight: FontWeight.w500,
                          height: 1.2125*ffem/fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                    Container(
                      // whatyouwanteattodayKwF (1:36)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 24*fem),
                      width: double.infinity,
                      child: Text(
                        'What you want eat today',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Inter',
                          fontSize: 24*ffem,
                          fontWeight: FontWeight.w300,
                          height: 1.2125*ffem/fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                    Container(
                      // autogroupknsu2qf (Sfezx9fEiDTAJD64jLKnSu)
                      margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 28*fem, 63*fem),
                      padding: EdgeInsets.fromLTRB(16*fem, 5*fem, 124*fem, 6*fem),
                      width: double.infinity,
                      decoration: BoxDecoration (
                        color: Color(0x9bd9d9d9),
                        borderRadius: BorderRadius.circular(10*fem),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // iconremovebgpreview18Nu (1:39)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 18*fem, 0*fem),
                            width: 32*fem,
                            height: 34*fem,
                            child: Image.asset(
                              'assets/page-1/images/icon-removebg-preview-1.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                          Container(
                            // searchforfoodqo7 (1:40)
                            margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 0*fem),
                            child: Text(
                              'Search for food',
                              textAlign: TextAlign.center,
                              style: SafeGoogleFont (
                                'Inter',
                                fontSize: 20*ffem,
                                fontWeight: FontWeight.w300,
                                height: 1.2125*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      // autogroup21qt9J1 (Sff1E4NPurxYd4dt4G21qT)
                      margin: EdgeInsets.fromLTRB(32*fem, 0*fem, 24.55*fem, 0*fem),
                      width: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // fGM (05677535)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 175.45*fem, 0*fem),
                            width: 133*fem,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // images6removebgpreview1C1P (1:43)
                                  width: 131*fem,
                                  height: 134*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/images6-removebg-preview-1.png',
                                    fit: BoxFit.cover,
                                  ),
                                ),
                                Container(
                                  // rectangle11j1K (1:41)
                                  width: double.infinity,
                                  height: 182*fem,
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                    color: Color(0xd8ffab07),
                                  ),
                                ),
                                Container(
                                  // pizzabuffetGmw (1:44)
                                  margin: EdgeInsets.fromLTRB(5*fem, 0*fem, 0*fem, 18*fem),
                                  constraints: BoxConstraints (
                                    maxWidth: 66*fem,
                                  ),
                                  child: Text(
                                    'Pizza\nBuffet',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 23*ffem,
                                      fontWeight: FontWeight.w300,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // N4H (07668443)
                            margin: EdgeInsets.fromLTRB(169*fem, 0*fem, 0*fem, 9*fem),
                            width: 139.45*fem,
                            height: 209*fem,
                            child: Container(
                              // 71s (33790772)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 75*fem),
                              width: double.infinity,
                              height: 134*fem,
                              child: Container(
                                // 3gD (70154039)
                                width: double.infinity,
                                height: 227*fem,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // Pzy (04361075)
                                      width: double.infinity,
                                      height: 227*fem,
                                      child: Container(
                                        // NTb (19530778)
                                        width: double.infinity,
                                        height: double.infinity,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            Container(
                                              // images7removebgpreview1Ktd (1:45)
                                              width: 139.45*fem,
                                              height: 134*fem,
                                              child: Image.asset(
                                                'assets/page-1/images/images7-removebg-preview-1.png',
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                            Container(
                                              // rectangle12mu3 (1:42)
                                              margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 3.45*fem, 0*fem),
                                              width: double.infinity,
                                              height: 182*fem,
                                              decoration: BoxDecoration (
                                                borderRadius: BorderRadius.circular(10*fem),
                                                border: Border.all(color: Color(0xff000000)),
                                                color: Color(0xffffffff),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Container(
                                      // paneerpizzaUoT (1:46)
                                      margin: EdgeInsets.fromLTRB(0.55*fem, 0*fem, 0*fem, 18*fem),
                                      constraints: BoxConstraints (
                                        maxWidth: 76*fem,
                                      ),
                                      child: Text(
                                        'Paneer\nPizza',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Inter',
                                          fontSize: 23*ffem,
                                          fontWeight: FontWeight.w300,
                                          height: 1.2125*ffem/fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          Container(
                            // ARP (78738573)
                            margin: EdgeInsets.fromLTRB(62*fem, 0*fem, 67.55*fem, 0*fem),
                            width: double.infinity,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // J1o (49353282)
                                  width: double.infinity,
                                  height: 231*fem,
                                  child: Container(
                                    // Fxd (86670689)
                                    width: double.infinity,
                                    height: double.infinity,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Container(
                                          // download7removebgpreview1pVw (1:48)
                                          width: 178.9*fem,
                                          height: 134*fem,
                                          child: Image.asset(
                                            'assets/page-1/images/download7-removebg-preview-1.png',
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                        Container(
                                          // rectangle139o7 (1:47)
                                          margin: EdgeInsets.fromLTRB(22*fem, 0*fem, 23.9*fem, 0*fem),
                                          width: double.infinity,
                                          height: 182*fem,
                                          decoration: BoxDecoration (
                                            borderRadius: BorderRadius.circular(10*fem),
                                            border: Border.all(color: Color(0xff000000)),
                                            color: Color(0xffffffff),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                Container(
                                  // dominospizzarhX (1:49)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4.9*fem, 22*fem),
                                  constraints: BoxConstraints (
                                    maxWidth: 94*fem,
                                  ),
                                  child: Text(
                                    'Dominos\nPizza',
                                    textAlign: TextAlign.center,
                                    style: SafeGoogleFont (
                                      'Inter',
                                      fontSize: 23*ffem,
                                      fontWeight: FontWeight.w300,
                                      height: 1.2125*ffem/fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                // autogroupjff79Rj (Sff1Ty8tJVhYi1VsE8Jff7)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
                padding: EdgeInsets.fromLTRB(13*fem, 0*fem, 13*fem, 0*fem),
                width: double.infinity,
                child: Text(
                  '\$24.95',
                  textAlign: TextAlign.center,
                  style: SafeGoogleFont (
                    'Inter',
                    fontSize: 24*ffem,
                    fontWeight: FontWeight.w300,
                    height: 1.2125*ffem/fem,
                    color: Color(0xff000000),
                  ),
                ),
              ),
              Container(
                // autogroupudgd1iq (Sff1YU1PdGvQkJYV5WUDgd)
                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                width: 211*fem,
                height: 44*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff000000)),
                  color: Color(0xffffab07),
                  borderRadius: BorderRadius.circular(15*fem),
                ),
                child: Center(
                  child: Text(
                    'Checkout',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 24*ffem,
                      fontWeight: FontWeight.w500,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
          );
  }
}