import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // loginmk5 (1:34)
        width: double.infinity,
        height: 842*fem,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0xff000000)),
          color: Color(0xffde2e4e),
        ),
        child: Stack(
          children: [
            Positioned(
              // autogroupnc5phdj (SfezHqRkB8T9NJFz53NC5P)
              left: 36*fem,
              top: 318*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(10*fem, 0*fem, 10*fem, 0*fem),
                width: 320*fem,
                height: 50*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(12*fem),
                ),
                child: Align(
                  // download5removebgpreview1Q2M (1:30)
                  alignment: Alignment.centerLeft,
                  child: SizedBox(
                    width: 33*fem,
                    height: 50*fem,
                    child: Image.asset(
                      'assets/page-1/images/download5-removebg-preview-1-XEH.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // loginXsf (1:26)
              left: 155*fem,
              top: 251*fem,
              child: Container(
                width: 87*fem,
                height: 48*fem,
                child: Center(
                  child: Text(
                    'Login',
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 32*ffem,
                      fontWeight: FontWeight.w600,
                      height: 1.5*ffem/fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroupbmdboqB (SfezMqK5o9yur7dePABMDB)
              left: 36*fem,
              top: 421*fem,
              child: Container(
                padding: EdgeInsets.fromLTRB(6*fem, 4*fem, 6*fem, 5*fem),
                width: 320*fem,
                height: 50*fem,
                decoration: BoxDecoration (
                  color: Color(0xffffffff),
                  borderRadius: BorderRadius.circular(12*fem),
                ),
                child: Align(
                  // download6removebgpreview1tLq (1:31)
                  alignment: Alignment.centerLeft,
                  child: SizedBox(
                    width: 41*fem,
                    height: 41*fem,
                    child: Image.asset(
                      'assets/page-1/images/download6-removebg-preview-1-jCm.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // illustratedyummyfoodtrucklogor (1:29)
              left: 38*fem,
              top: 9*fem,
              child: Align(
                child: SizedBox(
                  width: 322*fem,
                  height: 260*fem,
                  child: Image.asset(
                    'assets/page-1/images/illustratedyummyfoodtrucklogo-removebg-preview-2.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Positioned(
              // autogroupkukvHNy (SfezRVseHM3wxHE116kukV)
              left: 74*fem,
              top: 723*fem,
              child: Container(
                width: 245*fem,
                height: 58*fem,
                decoration: BoxDecoration (
                  border: Border.all(color: Color(0xff000000)),
                  color: Color(0xffffab07),
                  borderRadius: BorderRadius.circular(15*fem),
                ),
                child: Center(
                  child: Text(
                    'Sign In',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Inter',
                      fontSize: 20*ffem,
                      fontWeight: FontWeight.w300,
                      height: 1.2125*ffem/fem,
                      color: Color(0xff000000),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}