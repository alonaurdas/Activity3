import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // getstartedGU1 (1:9)
        padding: EdgeInsets.fromLTRB(10*fem, 26*fem, 10*fem, 56*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffde2e4e),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupnxmp5Jy (Sfey3NWVHuDFB7s8ufNxmP)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 15*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // illustratedyummyfoodtrucklogor (1:4)
                    width: 373*fem,
                    height: 395*fem,
                    child: Image.asset(
                      'assets/page-1/images/illustratedyummyfoodtrucklogo-removebg-preview-1.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                  Container(
                    // deliciousfoodJhX (1:5)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 1*fem, 0*fem),
                    child: Text(
                      'Delicious Food',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 32*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupmfvhNxH (SfeyBsGLEhxshEHR5AMfvh)
              margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 75*fem),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // wehelpyoutofindbestdeliciousfo (1:6)
                    constraints: BoxConstraints (
                      maxWidth: 372*fem,
                    ),
                    child: Text(
                      'We help you to find best \ndelicious food',
                      textAlign: TextAlign.center,
                      style: SafeGoogleFont (
                        'Inter',
                        fontSize: 32*ffem,
                        fontWeight: FontWeight.w300,
                        height: 1.2125*ffem/fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                  Container(
                    // removebgpreview1cLq (1:3)
                    width: 150*fem,
                    height: 144*fem,
                    child: Image.asset(
                      'assets/page-1/images/removebg-preview-1.png',
                      fit: BoxFit.cover,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupscqwwtu (SfeyGs81GEsqHzzzToscqw)
              margin: EdgeInsets.fromLTRB(64*fem, 0*fem, 64*fem, 0*fem),
              width: double.infinity,
              height: 58*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff000000)),
                color: Color(0xffffab07),
                borderRadius: BorderRadius.circular(15*fem),
              ),
              child: Center(
                child: Text(
                  'Get Started',
                  textAlign: TextAlign.center,
                  style: SafeGoogleFont (
                    'Inter',
                    fontSize: 20*ffem,
                    fontWeight: FontWeight.w300,
                    height: 1.2125*ffem/fem,
                    color: Color(0xff000000),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}