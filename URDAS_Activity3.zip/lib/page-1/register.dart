import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 393;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // registerVzH (1:23)
        padding: EdgeInsets.fromLTRB(34*fem, 6*fem, 37*fem, 56*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0xff000000)),
          color: Color(0xffde2e4e),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // illustratedyummyfoodtrucklogor (1:17)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
              width: 322*fem,
              height: 274*fem,
              child: Image.asset(
                'assets/page-1/images/illustratedyummyfoodtrucklogo-removebg-preview-2-XeR.png',
                fit: BoxFit.cover,
              ),
            ),
            Container(
              // createaccountbvq (1:11)
              margin: EdgeInsets.fromLTRB(10*fem, 0*fem, 0*fem, 20*fem),
              child: Text(
                'Create Account',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Inter',
                  fontSize: 32*ffem,
                  fontWeight: FontWeight.w700,
                  height: 1.2125*ffem/fem,
                  color: Color(0xffffffff),
                ),
              ),
            ),
            Container(
              // autogroup2cuzWgR (SfeycGjLPADtYCFWZb2cUZ)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 51*fem),
              padding: EdgeInsets.fromLTRB(3*fem, 4*fem, 3*fem, 3*fem),
              width: 320*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff000000)),
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(12*fem),
              ),
              child: Align(
                // download16removebgpreview1PVK (1:18)
                alignment: Alignment.centerLeft,
                child: SizedBox(
                  width: 43*fem,
                  height: 43*fem,
                  child: Image.asset(
                    'assets/page-1/images/download16-removebg-preview-1.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Container(
              // autogroupn9zhuCm (SfeyhbunYXbaWckPeQn9zH)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 51*fem),
              padding: EdgeInsets.fromLTRB(8*fem, 0*fem, 8*fem, 0*fem),
              width: 320*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff000000)),
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(12*fem),
              ),
              child: Align(
                // download5removebgpreview1CBs (1:19)
                alignment: Alignment.centerLeft,
                child: SizedBox(
                  width: 33*fem,
                  height: 50*fem,
                  child: Image.asset(
                    'assets/page-1/images/download5-removebg-preview-1.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Container(
              // autogroupwi1oivu (Sfeyn6nHsJpSYuo1Vnwi1o)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 51*fem),
              padding: EdgeInsets.fromLTRB(8*fem, 3*fem, 8*fem, 6*fem),
              width: 320*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff000000)),
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(12*fem),
              ),
              child: Align(
                // download6removebgpreview12Au (1:20)
                alignment: Alignment.centerLeft,
                child: SizedBox(
                  width: 41*fem,
                  height: 41*fem,
                  child: Image.asset(
                    'assets/page-1/images/download6-removebg-preview-1.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Container(
              // autogroupfeg9xKT (SfeysWnwK8op7kEiWAFeg9)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 50*fem),
              padding: EdgeInsets.fromLTRB(6*fem, 4*fem, 6*fem, 4*fem),
              width: 320*fem,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(12*fem),
              ),
              child: Align(
                // download17removebgpreview14NV (1:16)
                alignment: Alignment.centerLeft,
                child: SizedBox(
                  width: 44*fem,
                  height: 42*fem,
                  child: Image.asset(
                    'assets/page-1/images/download17-removebg-preview-1.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            Container(
              // autogroup4ns3Pff (SfeyzLvtamFnmbkUCn4Ns3)
              margin: EdgeInsets.fromLTRB(44*fem, 0*fem, 33*fem, 0*fem),
              width: double.infinity,
              height: 58*fem,
              decoration: BoxDecoration (
                border: Border.all(color: Color(0xff000000)),
                color: Color(0xffffab07),
                borderRadius: BorderRadius.circular(15*fem),
              ),
              child: Center(
                child: Text(
                  'Sign Up',
                  textAlign: TextAlign.center,
                  style: SafeGoogleFont (
                    'Inter',
                    fontSize: 20*ffem,
                    fontWeight: FontWeight.w300,
                    height: 1.2125*ffem/fem,
                    color: Color(0xff000000),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}